# Good Vibes
 
 Good Vibes is a project that aims to create a safe space for teenagers during the lockdown. It is built by a team of high school coders from all around the world and will have multiple features on both an iOS/Android app and a universal PWA. 
 
 The code for this project is copyrighted and is the intellectual property of the owners. It may not be shared, reproduced, or edited in any form without the express permission of the owners (iAarush, izzyASC5, and BilarMokhtari). Please contact them in case you need any clarifications or would like to share/reproduce/edit the code.
